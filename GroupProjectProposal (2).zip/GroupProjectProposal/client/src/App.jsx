import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import RegLoginPage from "./pages/RegLoginPage";
import HomePage from "./pages/HomePage";
import AddDrinkPage from "./pages/AddDrinkPage";
import DetailsPage from "./pages/DetailsPage";
import UpdatePage from "./pages/UpdatePage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<RegLoginPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/add" element={<AddDrinkPage />} />
        <Route path="/:id" element={<DetailsPage />} />
        <Route path="/update/:id" element={<UpdatePage />} />
      </Routes>
    </Router>
  );
}

export default App;


