import LoginForm from '../components/LoginForm';
import RegistrationForm from '../components/RegistrationForm';

function RegLoginPage() {
    return (
        <div>
            <h2>Register</h2>
            <RegistrationForm />
            <h2>Login</h2>
            <LoginForm />
        </div>
    );
}

export default RegLoginPage;
