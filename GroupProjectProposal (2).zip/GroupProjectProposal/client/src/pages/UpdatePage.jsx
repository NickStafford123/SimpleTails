import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import DrinkForm from '../components/DrinkForm';

function UpdatePage() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [drinkData, setDrinkData] = useState(null);

    useEffect(() => {
        const fetchDrinkData = async () => {
            try {
                const token = localStorage.getItem('token'); // Retrieve the token from local storage
                const response = await axios.get(`http://localhost:8000/api/drinks/${id}`, {
                    headers: {
                        'Authorization': `Bearer ${token}` // Include the token in the Authorization header
                    }
                });
                setDrinkData(response.data);
            } catch (error) {
                console.error('Error fetching drink data:', error);
                // Optional: Redirect to login page if the token is invalid or missing
                if (error.response && error.response.status === 401) {
                    navigate('/login');
                }
            }
        };
        fetchDrinkData();
    }, [id, navigate]); 

    const handleHomeClick = () => {
        navigate('/home');
    };

    const handleLogoutClick = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    return (
        <div>
            <h1>Simple Tails</h1>
            <button onClick={handleHomeClick}>Home</button>
            <button onClick={handleLogoutClick}>Logout</button>
            {drinkData && <DrinkForm initialData={drinkData} />}
        </div>
    );
}

export default UpdatePage;

