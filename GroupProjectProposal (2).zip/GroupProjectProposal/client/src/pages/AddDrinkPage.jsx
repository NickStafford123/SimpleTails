import { useNavigate } from 'react-router-dom';
import DrinkForm from '../components/DrinkForm';

function AddDrinkPage() {
    const navigate = useNavigate();

    return (
        <div>
            <h1>Simple Tails</h1>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <button onClick={() => navigate('/home')}>Home</button>
                <button onClick={() => navigate('/')}>Logout</button>
            </div>
            <h2>New Drink</h2>
            <DrinkForm />
        </div>
    );
}

export default AddDrinkPage;
