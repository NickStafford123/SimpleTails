import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function HomePage() {
    const navigate = useNavigate();
    const [drinks, setDrinks] = useState([]);
    const [filter, setFilter] = useState('');

    // Fetch drinks from the server
    useEffect(() => {
        const fetchDrinks = async () => {
            const response = await axios.get('http://localhost:8000/api/drinks/allDrinks');
            setDrinks(response.data);
        };

        fetchDrinks();
    }, []);

    // Filter drinks based on the selected liquor type
    const filteredDrinks = filter ? drinks.filter(drink => drink.liquor === filter) : drinks;

    // Handle logout
    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    };

    // Handle navigation to Add New Drink Page
    const handleAddNewDrink = () => {
        navigate('/add');
    };

    // Handle drink view
    const handleViewDrink = (id) => {
        navigate(`/${id}`);
    };

    return (
        <div>
            <h1>Simple Tails</h1>
            <button onClick={handleLogout}>Logout</button>
            <button onClick={handleAddNewDrink}>Create New Drink</button>
            <h2>Simple drink recipes!</h2>
            <h3>All Drinks</h3>
            <select onChange={e => setFilter(e.target.value)}>
                <option value="">Apply Filter</option>
                <option value="Vodka">Vodka</option>
                <option value="Tequila">Tequila</option>
                <option value="Rum">Rum</option>
                <option value="Whiskey">Whiskey</option>
            </select>
            <ul>
                {filteredDrinks.map(drink => (
                    <li key={drink._id}>
                        {drink.name} - <button onClick={() => handleViewDrink(drink._id)}>View</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default HomePage;
