import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

function DetailsPage() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [drink, setDrink] = useState(null);
    const [isOwner, setIsOwner] = useState(false);

    useEffect(() => {
        const fetchDrink = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await axios.get(`http://localhost:8000/api/drinks/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setDrink(response.data);
                const userId = localStorage.getItem('userId'); // Assuming the user's ID is stored in local storage
                setIsOwner(response.data.user === userId);
            } catch (error) {
                console.error(error);
                // Handle error
            }
        };

        fetchDrink();
    }, [id]);

    const handleDelete = async () => {
        try {
            const token = localStorage.getItem('token');
            await axios.delete(`http://localhost:8000/api/drinks/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            navigate('/home');
        } catch (error) {
            console.error(error);
            // Handle error
        }
    };

    if (!drink) return <div>Loading...</div>;

    return (
        <div>
            <h1>Simple Tails</h1>
            <button onClick={() => navigate('/home')}>Home</button>
            <button onClick={() => {
                localStorage.removeItem('token');
                navigate('/');
            }}>Logout</button>
            <h2>{drink.name}</h2>
            {drink.picture && <img src={drink.picture} alt={drink.name} />}
            <p>{drink.recipe}</p>
            {isOwner && (
                <>
                    <button onClick={() => navigate(`/update/${id}`)}>Edit</button>
                    <button onClick={handleDelete}>Delete</button>
                </>
            )}
        </div>
    );
}

export default DetailsPage;

