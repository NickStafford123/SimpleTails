import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function DrinkForm() {
    const navigate = useNavigate();
    const [name, setName] = useState('');
    const [recipe, setRecipe] = useState('');
    const [liquor, setLiquor] = useState('');
    const [picture, setPicture] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        const formData = new FormData();
        formData.append('name', name);
        formData.append('recipe', recipe);
        formData.append('liquor', liquor);
        if (picture) {
            formData.append('picture', picture);
        }
    
        const token = localStorage.getItem('token');
    
        try {
            const response = await axios.post('http://localhost:8000/api/drinks/add', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization': `Bearer ${token}`
                }
            });
            console.log(response.data._id);
            navigate(`/home`); 
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" required />
            <textarea value={recipe} onChange={(e) => setRecipe(e.target.value)} placeholder="Recipe" required />
            <select value={liquor} onChange={(e) => setLiquor(e.target.value)} required>
                <option value="">Select Liquor Type</option>
                <option value="Vodka">Vodka</option>
                <option value="Tequila">Tequila</option>
                <option value="Rum">Rum</option>
                <option value="Whiskey">Whiskey</option>
            </select>
            <input type="file" onChange={(e) => setPicture(e.target.files[0])} />
            <button type="submit">Submit</button>
        </form>
    );
}

export default DrinkForm;

